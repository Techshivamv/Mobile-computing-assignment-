package com.example.flutter_assignment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
